/**
 * Stack class configuration file.
 * Activate test #N by defining the corresponding LAB6_TESTN to have the value 1.
 */

#define LAB6_TEST1	1	// 0 => use array implementation, 1 => use linked impl.

